import{m as a}from"./p-796702c0.js";
/*!
 * (C) Ionic http://ionicframework.com - MIT License
 */
const t=async t=>{const s=await a.get(t);return!(!s||!await s.isActive())};export{t as u}