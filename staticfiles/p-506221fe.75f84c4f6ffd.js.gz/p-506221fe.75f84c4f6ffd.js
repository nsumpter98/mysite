/*!
 * (C) Ionic http://ionicframework.com - MIT License
 */
const o=o=>o&&""!==o.dir?"rtl"===o.dir.toLowerCase():"rtl"===(null===document||void 0===document?void 0:document.dir.toLowerCase());export{o as i}